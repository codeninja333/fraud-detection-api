package com.tejas.fraud_detection_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudDetectionApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
