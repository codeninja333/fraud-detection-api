package com.tejas.fraud_detection_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudDetectionApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudDetectionApiApplication.class, args);
	}

}
